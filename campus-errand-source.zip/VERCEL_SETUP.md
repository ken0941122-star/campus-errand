# Vercel 部署完整指南

## 概述

Vercel 是一個無伺服器部署平台，可以自動部署你的應用。本指南說明如何將校園跑腿 APP 的後端伺服器部署到 Vercel。

**注意：** 
- Expo 行動應用本身透過 Expo Go 或 EAS Build 部署
- Vercel 用於部署後端 API 伺服器（Express + tRPC）

---

## 步驟 1：準備 Vercel 帳號

### 1.1 登入 Vercel

1. 開啟瀏覽器，進入 https://vercel.com
2. 點「Sign Up」或「Sign In」
3. 選「Continue with GitHub」
4. 授權 Vercel 存取你的 GitHub 帳號

### 1.2 驗證帳號

完成郵箱驗證（如果需要）

---

## 步驟 2：連接 GitHub 倉庫

### 2.1 建立新專案

1. 登入 Vercel 後，進入 Dashboard
2. 點「Add New...」→「Project」

### 2.2 匯入 GitHub 倉庫

1. 選「Import Git Repository」
2. 在搜尋框輸入 `campus-errand`
3. 選擇你的 `campus-errand` 倉庫
4. 點「Import」

### 2.3 設定專案

頁面會跳轉到「Configure Project」

| 設定項 | 值 |
|--------|-----|
| **Framework Preset** | Other |
| **Root Directory** | `./` |
| **Build Command** | `pnpm build` |
| **Output Directory** | `dist` |
| **Install Command** | `pnpm install` |

### 2.4 新增環境變數

在「Environment Variables」部分，新增以下變數：

| 名稱 | 值 | 作用 |
|------|-----|------|
| `EXPO_PUBLIC_SUPABASE_URL` | `https://zptamzjsqhikzcqoydyj.supabase.co` | Supabase URL |
| `EXPO_PUBLIC_SUPABASE_ANON_KEY` | `sbp_4b5a4ac52d6a1ba9bf491a7646eec3db34a705c5` | Supabase 公開金鑰 |

**步驟：**
1. 點「Add New」
2. 輸入環境變數名稱
3. 輸入值
4. 點「Save」

### 2.5 部署

1. 確認所有設定正確
2. 點「Deploy」按鈕
3. 等待部署完成（通常 2-5 分鐘）

---

## 步驟 3：驗證部署

### 3.1 查看部署狀態

1. 部署完成後，你會看到一個成功訊息
2. 點擊「Visit」查看部署的應用

### 3.2 檢查後端 API

後端 API 應該在以下 URL 可用：

```
https://campus-errand-<random>.vercel.app
```

測試 API 端點：

```bash
curl https://campus-errand-<random>.vercel.app/api/health
```

### 3.3 檢查日誌

1. 在 Vercel Dashboard 選擇你的專案
2. 進入「Deployments」標籤
3. 點最新的部署
4. 查看「Logs」

---

## 步驟 4：設定自動部署

### 4.1 自動部署規則

Vercel 預設會在以下情況自動部署：

- 推送代碼到 `main` 分支
- 建立 Pull Request

### 4.2 禁用自動部署（可選）

如果想手動控制部署：

1. 進入專案設定 → Git
2. 取消勾選「Automatic Deployments」

### 4.3 手動部署

如果禁用了自動部署，可以手動觸發：

1. 進入「Deployments」
2. 點「Redeploy」

---

## 步驟 5：設定自訂域名（可選）

### 5.1 新增域名

1. 進入專案設定 → Domains
2. 輸入你的域名（例如：`api.campus-errand.com`）
3. 點「Add」

### 5.2 設定 DNS

按照 Vercel 提供的指示，在你的域名提供商設定 DNS 記錄

---

## 步驟 6：監控和維護

### 6.1 查看分析

1. 進入「Analytics」標籤
2. 查看流量、效能等資訊

### 6.2 查看日誌

1. 進入「Logs」標籤
2. 查看應用日誌和錯誤

### 6.3 設定告警（可選）

1. 進入「Settings」→「Alerts」
2. 設定失敗部署、高錯誤率等告警

---

## 環境變數管理

### 在 Vercel 中管理環境變數

1. 進入專案設定 → Environment Variables
2. 新增、編輯或刪除變數

### 不同環境的環境變數

Vercel 支援為不同環境設定不同的環境變數：

- **Production**：部署到 `main` 分支時使用
- **Preview**：部署 Pull Request 時使用
- **Development**：本地開發時使用

### 設定環境特定的變數

1. 點「Add New」
2. 輸入變數名稱和值
3. 在「Environment」下拉選單選擇環境
4. 點「Save」

---

## 常見問題

### Q: 部署失敗，錯誤訊息是什麼？

**解決方法：**
1. 進入 Deployments 查看失敗的部署
2. 點進去查看「Build Logs」
3. 找出錯誤訊息
4. 修復代碼並推送到 GitHub
5. Vercel 會自動重新部署

### Q: 如何查看後端 API 是否正常運作？

**解決方法：**
```bash
# 測試 API 健康檢查
curl https://your-vercel-app.vercel.app/api/health

# 測試 tRPC 端點
curl https://your-vercel-app.vercel.app/api/trpc/tasks.list
```

### Q: 環境變數沒有生效

**解決方法：**
1. 確認環境變數已正確設定
2. 重新部署應用
3. 清除瀏覽器快取
4. 檢查代碼是否正確讀取環境變數

### Q: 如何回滾到上一個版本？

**解決方法：**
1. 進入「Deployments」
2. 找到想要回滾的版本
3. 點「...」→「Redeploy」

### Q: 如何刪除 Vercel 上的應用？

**解決方法：**
1. 進入專案設定 → General
2. 向下滾動到「Danger Zone」
3. 點「Delete Project」

---

## 部署檢查清單

- [ ] 在 Vercel 建立帳號並登入
- [ ] 連接 GitHub 倉庫到 Vercel
- [ ] 設定環境變數（SUPABASE_URL、ANON_KEY）
- [ ] 設定構建命令和輸出目錄
- [ ] 部署成功
- [ ] 驗證後端 API 正常運作
- [ ] 設定自動部署
- [ ] 檢查部署日誌

---

## 後端 API 端點

部署後，你的後端 API 可以在以下 URL 存取：

```
https://campus-errand-<random>.vercel.app
```

### 可用的 API 端點

| 端點 | 方法 | 說明 |
|------|------|------|
| `/api/health` | GET | 健康檢查 |
| `/api/trpc/tasks.list` | GET | 列出所有任務 |
| `/api/trpc/tasks.create` | POST | 建立任務 |
| `/api/trpc/tasks.get` | GET | 取得任務詳情 |
| `/api/trpc/tasks.accept` | POST | 接受任務 |

---

## 在 Expo 應用中使用 Vercel API

如果你想在 Expo 應用中呼叫後端 API，可以這樣做：

```tsx
import axios from 'axios';

const API_BASE_URL = 'https://campus-errand-<random>.vercel.app';

// 建立任務
const createTask = async (taskData) => {
  const response = await axios.post(`${API_BASE_URL}/api/trpc/tasks.create`, taskData);
  return response.data;
};

// 列出任務
const listTasks = async () => {
  const response = await axios.get(`${API_BASE_URL}/api/trpc/tasks.list`);
  return response.data;
};
```

---

## 下一步

完成 Vercel 部署後：

1. ✅ 後端 API 已部署到 Vercel
2. ✅ Expo 應用可以連接 Supabase
3. ✅ 代碼已同步到 GitHub

**建議的後續步驟：**
- 修改 Expo 應用整合 Supabase Hooks
- 新增登入/註冊頁面
- 測試端到端流程
- 設定 CI/CD 自動測試
