# 校園跑腿 APP - TODO

## 品牌與設定
- [x] 生成 APP 圖示（橙色跑腿主題）
- [x] 更新 app.config.ts 品牌資訊
- [x] 設定主題色彩（橙色系）

## 資料層
- [x] 建立本地資料類型定義（Task、Order、User、Review）
- [x] 建立 AsyncStorage 資料存取工具
- [x] 建立任務 Context（TaskContext）
- [x] 建立訂單 Context（OrderContext）
- [x] 建立使用者 Context（UserContext）

## 導覽架構
- [x] 設定底部 Tab Bar（首頁、發單、我的訂單、個人）
- [x] 新增所有 Tab 圖示映射
- [x] 建立頁面路由結構

## 首頁（探索任務）
- [x] 任務卡片元件
- [x] 任務分類標籤列
- [x] 搜尋欄位
- [x] 任務列表（FlatList）
- [x] 空狀態顯示

## 發單功能
- [x] 發單表單頁面
- [x] 任務類別選擇
- [x] 地點輸入欄位
- [x] 報酬與截止時間設定
- [x] 表單驗證
- [x] 發布任務邏輯

## 任務詳情
- [x] 任務詳情頁面
- [x] 接受任務按鈕與邏輯
- [x] 發單人資訊顯示

## 我的訂單
- [x] 訂單列表頁（分頁：發出的 / 接的）
- [x] 訂單卡片元件（含狀態標籤）
- [x] 訂單詳情頁面
- [x] 狀態更新操作（確認完成、確認收貨、取消）

## 個人頁面
- [x] 個人資料展示（暱稱、評分、統計）
- [x] 設定暱稱功能
- [x] 我的評價列表

## 評價功能
- [x] 評價表單（星級 + 文字）
- [x] 評價提交邏輯

## UI 優化
- [x] 繁體中文全面本地化
- [x] 載入狀態動畫
- [x] 錯誤提示 Toast
- [x] 空狀態插圖與文字


## Bug 修復
- [x] 修復首頁過濾邏輯，允許顯示自己發的任務
- [x] 新增清除資料功能（個人頁面）用於測試

## Supabase 整合（進行中）
- [ ] 建立 Supabase 資料表 schema（users、errands、bids、messages、transactions）
- [ ] 設定 RLS 權限規則
- [ ] 在專案中安裝 supabase-js 套件
- [ ] 建立 Supabase Client 初始化檔案
- [ ] 遷移發單功能到 Supabase
- [ ] 遷移接單功能到 Supabase
- [ ] 遷移訂單查詢到 Supabase
- [ ] 設定環境變數（NEXT_PUBLIC_SUPABASE_URL、NEXT_PUBLIC_SUPABASE_ANON_KEY）
- [ ] 設定 GitHub 版本控制
- [ ] 設定 Vercel 後端部署
- [ ] 測試端到端雲端同步
